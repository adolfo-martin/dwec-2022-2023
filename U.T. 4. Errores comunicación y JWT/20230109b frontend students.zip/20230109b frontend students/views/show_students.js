import StudentsService from '../services/StudentsService.js';

document.addEventListener('DOMContentLoaded', setup);

async function setup(e) {
    const view = new ShowStudentsView();
    await view.retrieveAndShowStudents();
}

class ShowStudentsView {
    async retrieveAndShowStudents() {
        try {
            this.showInfo('Espere, por favor. Estamos recuperando la información necesaria.');

            const service = new StudentsService();
            const students = await service.retrieveStudents();

            const nTbody = document.querySelector('#tTabStudents>tbody');

            students.forEach(createRow);

            const nDialog = document.querySelector('#tDlgMessage');
            nDialog.close();

            function createRow(student) {
                const nTr = document.createElement('tr');
                nTbody.appendChild(nTr);

                const nTd = document.createElement('td');
                nTr.appendChild(nTd);
                nTd.textContent = `${student.firstname} ${student.lastname}`;
            }

        } catch (error) {
            const nDialog = document.querySelector('#tDlgMessage');
            nDialog.close();
            this.showError(`Problema al recuperar los estudiantes: ${error}`);
        }
    }


    showInfo(info) {
        const nDialog = document.querySelector('#tDlgMessage');
        nDialog.showModal();
        const nHeader = document.querySelector('#tDlgMessage>header');
        nHeader.textContent = 'Información';
        const nParagraph = document.querySelector('#tDlgMessage>p');
        nParagraph.textContent = info;
        const nButton = document.querySelector('#tDlgMessage>button');
        nButton.addEventListener('click', e => nDialog.close());
    }

    showError(error) {
        const nDialog = document.querySelector('#tDlgMessage');
        nDialog.showModal();
        const nHeader = document.querySelector('#tDlgMessage>header');
        nHeader.textContent = 'Error';
        const nParagraph = document.querySelector('#tDlgMessage>p');
        nParagraph.textContent = error;
        const nButton = document.querySelector('#tDlgMessage>button');
        nButton.addEventListener('click', e => nDialog.close());
    }
}