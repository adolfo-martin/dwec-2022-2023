export default class Student {
    constructor(
        public readonly uuid: string,
        public readonly firstname: string,
        public readonly lastname: string
    ) { }
}